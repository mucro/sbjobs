=== StartupBrett Job Widget ===
Contributors: mucrode
Tags: widget widget,shortcode,job,startup
Tested up to: 4.4.2

Mehrwert für deine Leser und Zusatzeinnahmen für dich, duch die Anzeige von StartupBrett Stellenanzeigen. Als Widget oder mittels Shortcode.

== Description ==
Werte deine Webseite/Blog auf mit Stellenanzeigen von StartupBrett.de. Damit lieferst du deinen Lesern nicht nur einen zusätzlichen Service, sondern schaffst als StartupBrett Affiliate auch noch ein zusätzliches Einkommen für deine Seite.

Das Plugin kann direkt als Widget oder über Shortcodes integriert werden. Dabei hast du verschiedene Möglichkeiten die Stellenanzeigen einzugrenzen und gemäß deinem Design darzustellen.

Probiere es einfach aus. Es entstehen keine Kosten für Dich. Lediglich Nutzen - für deine Leser und für dich.

Über Feedback freuen wir uns sehr.

== Installation ==
Zur Installation beachten Sie bitte folgende Schritte:

Die Plugindateien nach wp-content/plugins/sbjobs kopieren, oder über das WordPress Backend: Plugins > Installieren > ZIP Datei hochladen.
*   Das Plugin im Plugin Menü von WordPress aktivieren.
*   Widget hinzufügen: Design > Widgets > "StartupBrett Job Widget" an die gewünsche Position ziehen
*   Widget konfigurieren > Speichern > Fertig!
*   Alternativ können Sie das Plugin auch an beliebiger Stelle mittels Shortcodes integrieren

== Frequently Asked Questions ==
Bislang keine

== Screenshots ==
1. Widget Einstellungen
2. Widget Darstellung
3. Shortcode Integration

== Changelog ==
1.0.0
*   Erste Version

== Upgrade Notice ==
keine